"""
test_v3_topsis_rad.py — Tests for V3: TOPSIS-RAD, specifically the rank-reversal regression test.

The single most important test in the entire suite: adding an irrelevant
alternative (Kenya) must NOT change the closeness coefficients or order of
UAE, Brazil, and Indonesia.

Run:  python -m pytest ranking_engine/tests/test_v3_topsis_rad.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import numpy as np
import pandas as pd
import pytest

from ranking_engine.criterion_mapping import CRITERIA, BENEFIT_MASK
from ranking_engine.topsis_rad import topsis_rad

# Fixed anchors that never change (not derived from the dataset)
VPL = np.array([1, 1, 1, 1, 1, 10, 10, 10], dtype=float)
DPL = np.array([10, 10, 10, 10, 10, 1, 1, 1], dtype=float)

# The verified weight vector from the implementation plan (§8.3)
WEIGHTS = np.array([0.1243, 0.0932, 0.3336, 0.1864, 0.0746, 0.0327, 0.0621, 0.0932])

# Three-market matrix (baseline)
THREE_MARKETS = pd.DataFrame(
    {"UAE": [8,7,8,9,7,3,4,3], "Brazil": [7,6,7,6,6,4,5,5], "Indonesia": [6,5,5,4,5,3,6,6]},
    index=CRITERIA
).T

# Four-market matrix (adding Kenya — a weak alternative)
KENYA_ROW = pd.DataFrame({"Kenya": [2, 2, 3, 2, 3, 8, 8, 9]}, index=CRITERIA).T
FOUR_MARKETS = pd.concat([THREE_MARKETS, KENYA_ROW])


class TestTOPSISRAD:

    def test_closeness_in_range(self):
        """Closeness coefficients must be in [0, 1]."""
        cc = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        assert (cc.values >= 0).all() and (cc.values <= 1).all()

    def test_uae_ranks_first_three_markets(self):
        """UAE should have the highest closeness coefficient in the 3-market set."""
        cc = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        assert cc.idxmax() == "UAE"

    def test_order_is_uae_brazil_indonesia(self):
        """Verified order from the implementation plan: UAE > Brazil > Indonesia."""
        cc = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        order = cc.sort_values(ascending=False).index.tolist()
        assert order == ["UAE", "Brazil", "Indonesia"]

    # ------------------------------------------------------------------
    # THE KEY TEST: Rank-Reversal Regression
    # ------------------------------------------------------------------

    def test_rank_reversal_proof_adding_kenya(self):
        """
        Adding Kenya (a weak alternative) must NOT change the closeness
        coefficients or rankings of UAE, Brazil, and Indonesia.

        This is the primary guarantee TOPSIS-RAD provides over standard TOPSIS.
        If this test fails, the VPL/DPL anchors are incorrectly derived from
        the data instead of being fixed analyst-defined constants.
        """
        cc_3 = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        cc_4 = topsis_rad(FOUR_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)

        for market in ["UAE", "Brazil", "Indonesia"]:
            np.testing.assert_almost_equal(
                cc_3[market], cc_4[market], decimal=6,
                err_msg=(
                    f"Rank reversal detected: {market}'s closeness changed when Kenya was added.\n"
                    f"Before: {cc_3[market]:.6f}, After: {cc_4[market]:.6f}"
                )
            )

    def test_rank_reversal_proof_order_unchanged(self):
        """The ranking order of original markets must be identical with and without Kenya."""
        cc_3 = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        cc_4 = topsis_rad(FOUR_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)

        original_order_3 = cc_3.sort_values(ascending=False).index.tolist()
        original_order_4 = [m for m in cc_4.sort_values(ascending=False).index if m != "Kenya"]

        assert original_order_3 == original_order_4, (
            f"Ranking order changed when Kenya was added.\n"
            f"3-market order: {original_order_3}\n"
            f"4-market order (Kenya removed): {original_order_4}"
        )

    def test_capping_at_dpl_works(self):
        """
        The DPL capping guarantee is about STABILITY of OTHER markets, not the capped one.

        When UAE's C1 score is inflated to 15 (above DPL=10), it is capped to 10.
        The correct TOPSIS-RAD contract is that Brazil's and Indonesia's closeness
        coefficients are completely unchanged — the geometric space for other markets
        is frozen.  (UAE's own closeness *can* differ because capping changes its
        distance to PIS, but that is mathematically correct and expected.)
        """
        above_dpl = THREE_MARKETS.copy()
        above_dpl.loc["UAE", "C1"] = 15.0   # above DPL[0] = 10

        cc_normal = topsis_rad(THREE_MARKETS, WEIGHTS, BENEFIT_MASK, VPL, DPL)
        cc_above  = topsis_rad(above_dpl, WEIGHTS, BENEFIT_MASK, VPL, DPL)

        # Brazil and Indonesia must be completely unaffected by UAE's inflated score
        for market in ["Brazil", "Indonesia"]:
            np.testing.assert_almost_equal(
                cc_normal[market], cc_above[market], decimal=6,
                err_msg=(
                    f"DPL capping failed: {market}'s closeness changed when UAE's score "
                    f"was inflated beyond DPL. Before={cc_normal[market]:.6f}, "
                    f"After={cc_above[market]:.6f}"
                )
            )
