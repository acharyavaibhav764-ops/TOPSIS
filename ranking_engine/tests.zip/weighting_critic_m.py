"""
weighting_critic_m.py — V2: CRITIC-M objective weights.

Concept
-------
Classic CRITIC (Diakoulaki et al., 1995) derives weights from the decision
matrix itself — no stakeholder survey needed.  The underlying logic:

  "A criterion earns high weight when it
   (a) actually discriminates between markets (high variance), AND
   (b) is not just echoing another criterion (low correlation with peers)."

Information content per criterion j:
    C_j = σ_j × Σ_k (1 - r_{jk})

where σ_j is the standard deviation of column j after normalization, and r_{jk}
is the Pearson correlation between columns j and k.

The final weight: W_j = C_j / Σ_k C_k

The problem with the original CRITIC is that it uses min-max normalization,
which forces the best and worst-observed jurisdiction to exactly 0 and 1.  One
extreme outlier stretches the whole scale, artificially inflating σ and hence
that criterion's weight — for the wrong reason.

CRITIC-M's fix: normalize around a robust center using logistic squash over
median/IQR instead of min-max.  A single outlier jurisdiction no longer
dominates the variance calculation.
"""

import numpy as np
import pandas as pd


def critic_m_weights(
    matrix: pd.DataFrame,
    benefit_mask: np.ndarray,
) -> np.ndarray:
    """
    Compute objective CRITIC-M weights from the decision matrix.

    Parameters
    ----------
    matrix       : pd.DataFrame (jurisdictions × criteria), values already on 1-10 scale
    benefit_mask : bool array length n_criteria — True = benefit, False = cost

    Returns
    -------
    np.ndarray shape (n_criteria,) summing to 1.0
    """
    X = matrix.values.astype(float).copy()

    # Step 1: direction-correct → everything becomes "higher is better"
    for j in range(X.shape[1]):
        col = X[:, j] if benefit_mask[j] else -X[:, j]
        med = np.median(col)
        iqr = float(np.subtract(*np.percentile(col, [75, 25]))) or 1e-9  # guard zero-IQR
        # Logistic squash: robust to outliers, bounded in (0,1)
        X[:, j] = 1.0 / (1.0 + np.exp(-(col - med) / iqr))

    # Step 2: information content = std × conflict (sum of 1-corr with every other crit)
    std = X.std(axis=0, ddof=1)
    corr_matrix = np.corrcoef(X, rowvar=False)
    conflict = (1.0 - corr_matrix).sum(axis=0)   # shape (n_criteria,)
    information = std * conflict

    if information.sum() == 0:
        raise ValueError("CRITIC-M: all criteria have zero information content — "
                         "check that your matrix has more than one row.")

    return information / information.sum()


def fuse_weights(
    w_bwm: np.ndarray,
    w_critic_m: np.ndarray,
    lam: float = 0.6,
) -> np.ndarray:
    """
    Convex combination of subjective (BWM) and objective (CRITIC-M) weights.

    w_fused = lam * w_bwm + (1 - lam) * w_critic_m

    Parameters
    ----------
    w_bwm      : BWM weight vector (subjective, from stakeholder survey)
    w_critic_m : CRITIC-M weight vector (objective, from matrix variance)
    lam        : float ∈ [0, 1]; lam=1 → pure expert opinion, lam=0 → pure data.
                 Expose this to the business as a single tunable knob, not buried.

    Returns
    -------
    np.ndarray summing to 1.0
    """
    if not 0.0 <= lam <= 1.0:
        raise ValueError(f"lam must be in [0, 1]; got {lam}")
    w = lam * w_bwm + (1.0 - lam) * w_critic_m
    return w / w.sum()  # re-normalize for floating-point safety
