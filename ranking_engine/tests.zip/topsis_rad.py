"""
topsis_rad.py — V3: TOPSIS-RAD (Reference points and Acceptability Dimensions).

Concept — The rank-reversal problem
-------------------------------------
Standard TOPSIS defines its Positive Ideal Solution (PIS) and Negative Ideal
Solution (NIS) from the best/worst scores *actually observed* in the current
dataset.  This means:

  1. You evaluate UAE, Brazil, Indonesia → PIS is anchored to UAE's scores.
  2. You add Kenya (much weaker) → NIS shifts → distances change for UAE/Brazil/Indonesia.
  3. UAE and Brazil may swap ranks, even though their underlying data never changed.

This is rank reversal.  It's a well-documented failure mode of standard TOPSIS
(see the literature review: doi.org/10.1016/j.omega.2014.11.009) and it's
especially dangerous here because we *constantly add new markets* to the pipeline.

The fix — TOPSIS-RAD
---------------------
Instead of deriving PIS/NIS from the observed dataset, we anchor them to
*analyst-defined, fixed reference levels* that never change:

  VPL (Vetoed Performance Level) — the minimum tolerable score per criterion.
      A jurisdiction scoring below VPL on any criterion should already be knocked
      out.  VPL effectively defines the "anti-ideal" independently of the data.

  DPL (Desired Performance Level) — the aspirational "good enough" score per
      criterion.  Crucially, market scores are *capped at DPL before normalizing*.
      This means one jurisdiction that scores 10/10 on demand scale cannot stretch
      the frontier and inflate everyone else's apparent distance.

Because VPL and DPL never move when markets are added or removed, the geometric
space is frozen.  Adding Kenya does not shift the origin.  Rank reversal is
structurally impossible, not just less likely.

Reference: Costa et al. (2026), "TOPSIS-RAD: Ranking According to Desires",
           arXiv:2606.07253
"""

import numpy as np
import pandas as pd


def topsis_rad(
    matrix: pd.DataFrame,
    weights: np.ndarray,
    benefit_mask: np.ndarray,
    vpl: np.ndarray,
    dpl: np.ndarray,
) -> pd.Series:
    """
    Compute TOPSIS-RAD closeness coefficients for each jurisdiction.

    Parameters
    ----------
    matrix       : pd.DataFrame (jurisdictions × criteria), 1-10 scores
    weights      : np.ndarray (n_criteria,), must sum to 1
    benefit_mask : bool array (n_criteria,) — True = benefit, False = cost
    vpl          : np.ndarray (n_criteria,) — Vetoed Performance Level (floor/ceiling)
                   For benefit criteria:  VPL is the floor (worst tolerable).
                   For cost criteria:     VPL is the ceiling (worst tolerable).
    dpl          : np.ndarray (n_criteria,) — Desired Performance Level (aspirational)
                   For benefit criteria:  DPL is the cap (any score above DPL → treated as DPL).
                   For cost criteria:     DPL is the floor (any score below DPL → treated as DPL).

    Returns
    -------
    pd.Series  — closeness coefficient per jurisdiction (higher = better), index = jurisdiction names
    """
    X = matrix.values.astype(float)

    # Step 1: cap scores at DPL to prevent any single market stretching the frontier
    # benefit: cap at DPL (top); cost: floor at DPL (bottom)
    X_capped = np.where(benefit_mask, np.minimum(X, dpl), np.maximum(X, dpl))

    # Step 2: normalize against FIXED anchors (VPL, DPL), not the data's own extremes
    anchors = np.vstack([vpl, dpl])                        # shape (2, n_criteria)
    denom = np.sqrt((anchors ** 2).sum(axis=0))            # scalar per column
    denom[denom == 0] = 1e-12                              # guard zero-denom
    Xn   = X_capped / denom
    Wn   = Xn * weights

    # Step 3: fixed PIS and NIS from DPL/VPL, not the data
    anchors_n = anchors / denom                            # shape (2, n_criteria)
    pis = np.where(benefit_mask, anchors_n[1], anchors_n[0]) * weights  # DPL for benefit, VPL for cost
    nis = np.where(benefit_mask, anchors_n[0], anchors_n[1]) * weights  # VPL for benefit, DPL for cost

    # Step 4: Euclidean distances to fixed PIS and NIS
    d_pos = np.sqrt(((Wn - pis) ** 2).sum(axis=1))
    d_neg = np.sqrt(((Wn - nis) ** 2).sum(axis=1))

    # Step 5: closeness coefficient — 0 = at anti-ideal, 1 = at ideal
    denom2 = d_pos + d_neg
    denom2[denom2 == 0] = 1e-12
    closeness = d_neg / denom2

    return pd.Series(closeness, index=matrix.index, name="closeness")
