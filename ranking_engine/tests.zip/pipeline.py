"""
pipeline.py — V6: Full pipeline orchestration.

Ties V0 through V5 together in the correct order and exposes a single
RankingPipeline.run() entry point.  The output is a list of RankingResult
objects — one per surviving jurisdiction — which is the final contract the
business layer, reporting layer, and DB writer consume.

Re-run triggers (as the doc specifies, this runs as a continuous loop):
  - New/updated RawFact rows arrive from the extraction pipeline → re-run everything
  - Management team submits a new BWM survey → re-run V2 onwards
  - A new jurisdiction is scoped in → V3/V4 are unaffected due to TOPSIS-RAD's
    fixed anchors (adding a market doesn't change existing closeness coefficients)
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field

from .schema import RawFact, EvidenceTag, RankingResult
from .criterion_mapping import CRITERIA, BENEFIT_MASK, MAPPING_FUNCTIONS
from .knockout import build_decision_matrix, knockout_screen, extract_capital_required
from .weighting_bwm import bwm_weights
from .weighting_critic_m import critic_m_weights, fuse_weights
from .topsis_rad import topsis_rad
from .robustness_smaa import smaa_topsis
from .robustness_mc import monte_carlo_robustness
from .knapsack import solve_multi_period


@dataclass
class PipelineConfig:
    """All configuration that the business layer can tune without touching math code."""

    # --- Hard knockout ---
    liquid_runway_usd: float = 5_000_000.0  # USD available for any single jurisdiction

    # --- Fixed TOPSIS-RAD anchors (VPL / DPL) ---
    # These are analyst-defined, never derived from the dataset.
    # Benefit criteria (C1-C5): VPL = floor, DPL = aspirational cap
    # Cost criteria  (C6-C8): VPL = worst-tolerable ceiling, DPL = aspirational floor
    vpl: np.ndarray = field(
        default_factory=lambda: np.array([1,1,1,1,1, 10,10,10], dtype=float)
    )
    dpl: np.ndarray = field(
        default_factory=lambda: np.array([10,10,10,10,10, 1,1,1], dtype=float)
    )

    # --- Weighting ---
    weight_lambda: float = 0.6  # λ=1 → pure BWM, λ=0 → pure CRITIC-M

    # --- BWM survey inputs ---
    bwm_best_idx:  int = 2                                         # C3 = Pathway Clarity
    bwm_worst_idx: int = 5                                         # C6 = Capital Burden
    bwm_a_B: np.ndarray = field(
        default_factory=lambda: np.array([3,4,1,2,5,9,6,4], dtype=float)
    )
    bwm_a_W: np.ndarray = field(
        default_factory=lambda: np.array([5,4,9,6,3,1,2,4], dtype=float)
    )

    # --- Robustness ---
    smaa_n_trials: int = 20_000
    mc_n_trials:   int = 10_000
    smaa_seed:     int = 42
    mc_seed:       int = 42

    # --- Knapsack ---
    wave_budgets:             list = field(default_factory=lambda: [8_000_000, 5_000_000])
    mutually_exclusive_groups: list = field(default_factory=list)   # e.g. [["Indonesia","Philippines"]]
    knapsack_alpha:           float = 0.6


class RankingPipeline:
    """End-to-end market ranking pipeline from raw facts to RankingResult list."""

    def __init__(self, config: PipelineConfig | None = None):
        self.cfg = config or PipelineConfig()

    def run(
        self,
        facts: list[RawFact],
        margin_12mo: dict[str, float] | None = None,
        verbose: bool = True,
    ) -> tuple[list[RankingResult], dict]:
        """
        Execute the full pipeline and return ranked results + intermediate artifacts.

        Parameters
        ----------
        facts        : list of RawFact from the extraction pipeline
        margin_12mo  : dict jurisdiction → expected 12-month contribution margin (USD)
                       Required for the knapsack value function; can be omitted to skip V5.
        verbose      : whether to print stage-by-stage progress

        Returns
        -------
        results      : list[RankingResult] sorted by rank
        artifacts    : dict of intermediate outputs (matrix, weights, rai, mc, allocation)
                       for debugging, logging, and downstream reporting
        """
        cfg = self.cfg

        # ---- V0: Matrix assembly + hard knockout -----------------------------------------
        if verbose: print("=== V0: Building decision matrix + knockout screen ===")
        matrix = build_decision_matrix(facts, MAPPING_FUNCTIONS)
        capital_required = extract_capital_required(facts)
        matrix = knockout_screen(matrix, capital_required, cfg.liquid_runway_usd)

        if matrix.empty:
            raise ValueError("All jurisdictions were knocked out by the capital screen. "
                             "Increase liquid_runway_usd or review C6 raw values.")

        # ---- V2: Weight vector -----------------------------------------------------------
        if verbose: print("=== V2: BWM + CRITIC-M weight fusion ===")
        w_bwm, xi = bwm_weights(
            CRITERIA, cfg.bwm_best_idx, cfg.bwm_worst_idx, cfg.bwm_a_B, cfg.bwm_a_W
        )
        w_cm   = critic_m_weights(matrix, BENEFIT_MASK)
        weights = fuse_weights(w_bwm, w_cm, cfg.weight_lambda)
        if verbose:
            print(f"  BWM consistency ratio xi = {xi:.4f}  "
                  f"({'OK' if xi < 0.1 else 'HIGH — consider re-surveying'})")
            for c, w in zip(CRITERIA, weights):
                print(f"  {c}: {w:.4f}")

        # ---- V3: TOPSIS-RAD point ranking -----------------------------------------------
        if verbose: print("=== V3: TOPSIS-RAD ranking ===")
        closeness = topsis_rad(matrix, weights, BENEFIT_MASK, cfg.vpl, cfg.dpl)
        ranked    = closeness.sort_values(ascending=False)
        if verbose:
            for rank, (jur, cc) in enumerate(ranked.items(), start=1):
                print(f"  #{rank} {jur}: closeness={cc:.4f}")

        # ---- V4a: SMAA ------------------------------------------------------------------
        if verbose: print(f"=== V4a: SMAA ({cfg.smaa_n_trials:,} trials) ===")
        rai, cwv = smaa_topsis(
            matrix, BENEFIT_MASK, cfg.vpl, cfg.dpl,
            n_trials=cfg.smaa_n_trials, seed=cfg.smaa_seed
        )

        # ---- V4b: Evidence-calibrated Monte Carlo ----------------------------------------
        if verbose: print(f"=== V4b: Monte Carlo ({cfg.mc_n_trials:,} trials) ===")
        mc_results = monte_carlo_robustness(
            base_matrix=matrix,
            facts=facts,
            weights=weights,
            benefit_mask=BENEFIT_MASK,
            vpl=cfg.vpl,
            dpl=cfg.dpl,
            n_trials=cfg.mc_n_trials,
            seed=cfg.mc_seed,
        )

        # ---- V5: Multi-period knapsack --------------------------------------------------
        allocation: dict[int, list[str]] = {}
        if margin_12mo is not None and cfg.wave_budgets:
            if verbose: print(f"=== V5: Knapsack ({len(cfg.wave_budgets)} waves) ===")
            allocation = solve_multi_period(
                closeness=closeness,
                capital_burden=capital_required,
                margin_12mo={m: margin_12mo.get(m, 0.0) for m in matrix.index},
                wave_budgets=cfg.wave_budgets,
                mutually_exclusive_groups=cfg.mutually_exclusive_groups,
                alpha=cfg.knapsack_alpha,
            )

        # ---- Assemble RankingResult list ------------------------------------------------
        market_to_wave: dict[str, int | None] = {}
        for wave_idx, chosen in allocation.items():
            for m in chosen:
                market_to_wave[m] = wave_idx + 1  # 1-indexed waves

        results: list[RankingResult] = []
        for rank, (jur, cc) in enumerate(ranked.items(), start=1):
            mc_row = mc_results.loc[jur] if jur in mc_results.index else None
            results.append(RankingResult(
                jurisdiction=jur,
                closeness=float(cc),
                rank=rank,
                rank_acceptability={int(col): float(rai.loc[jur, col]) for col in rai.columns},
                mc_90pct_interval=(
                    float(mc_row["p5"]) if mc_row is not None else 0.0,
                    float(mc_row["p95"]) if mc_row is not None else 0.0,
                ),
                expansion_wave=market_to_wave.get(jur, None),
            ))

        artifacts = {
            "decision_matrix": matrix,
            "weights": dict(zip(CRITERIA, weights)),
            "bwm_consistency_xi": xi,
            "closeness": closeness,
            "rai": rai,
            "central_weight_vectors": cwv,
            "mc_intervals": mc_results,
            "expansion_allocation": allocation,
        }

        return results, artifacts
