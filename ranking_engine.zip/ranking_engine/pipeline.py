"""
pipeline.py — V6: Full pipeline orchestration.

Ties V0 through V5 together in the correct order and exposes a single
RankingPipeline.run() entry point.  The output is a list of RankingResult
objects — one per surviving jurisdiction — which is the final contract the
business layer, reporting layer, and DB writer consume.

Re-run triggers (as the doc specifies, this runs as a continuous loop):
  - New/updated RawFact rows arrive from the extraction pipeline → re-run everything
  - Management team submits a new BWM survey → re-run V2 onwards
  - A new jurisdiction is scoped in → V3/V4 are unaffected due to TOPSIS-RAD's
    fixed anchors (adding a market doesn't change existing closeness coefficients)
"""

import numpy as np
import pandas as pd
import json
import os
import dataclasses
from dataclasses import dataclass, field
from datetime import date

from .schema import RawFact, EvidenceTag, RankingResult
from .criterion_mapping import CRITERIA, BENEFIT_MASK, MAPPING_FUNCTIONS
from .knockout import build_decision_matrix, knockout_screen, extract_capital_required
from .weighting_bwm import bwm_weights
from .weighting_critic_m import critic_m_weights, fuse_weights
from .topsis_rad import topsis_rad
from .robustness_smaa import smaa_topsis
from .robustness_mc import monte_carlo_robustness
from .knapsack import solve_multi_period


@dataclass
class PipelineConfig:
    """All configuration that the business layer can tune without touching math code."""

    # --- Hard knockout ---
    liquid_runway_usd: float = 5_000_000.0  # USD available for any single jurisdiction

    # --- Fixed TOPSIS-RAD anchors (VPL / DPL) ---
    # These are analyst-defined constants, never derived from the dataset.
    # The matrix is fully direction-corrected (higher = better for ALL 8 columns),
    # so VPL and DPL are uniform — no split between benefit and cost criteria.
    #
    # VPL = 1.0 for all: the worst conceivable score on the 1-10 scale.
    # DPL = 8.5 for all: any market scoring above 8.5 is capped at 8.5 —
    #   one outstanding criterion cannot geometrically dominate the TOPSIS space.
    #   Setting DPL = 10.0 (scale boundary) makes capping a no-op; keep it < 10.
    #
    # These values must be decided by the actual management team before production use
    # (the plan explicitly calls for this — these are reasonable analyst defaults only).
    vpl: np.ndarray = field(
        default_factory=lambda: np.array([1.0] * 8, dtype=float)
    )
    dpl: np.ndarray = field(
        default_factory=lambda: np.array([8.5] * 8, dtype=float)
    )

    # --- Weighting ---
    weight_lambda: float = 0.6  # λ=1 → pure BWM, λ=0 → pure CRITIC-M

    # --- BWM survey inputs ---
    bwm_best_idx:  int = 2                                         # C3 = Pathway Clarity
    bwm_worst_idx: int = 5                                         # C6 = Capital Burden
    bwm_a_B: np.ndarray = field(
        default_factory=lambda: np.array([3,4,1,2,5,9,6,4], dtype=float)
    )
    bwm_a_W: np.ndarray = field(
        default_factory=lambda: np.array([5,4,9,6,3,1,2,4], dtype=float)
    )

    # --- Robustness ---
    smaa_n_trials: int = 20_000
    mc_n_trials:   int = 10_000
    smaa_seed:     int = 42
    mc_seed:       int = 42

    # --- Knapsack ---
    wave_budgets:             list = field(default_factory=lambda: [8_000_000, 5_000_000])
    mutually_exclusive_groups: list = field(default_factory=list)   # e.g. [["Indonesia","Philippines"]]
    knapsack_alpha:           float = 0.6


def _dump_stage_artifacts(
    dump_dir: str,
    facts: list,
    pre_knockout_matrix: "pd.DataFrame",
    post_knockout_matrix: "pd.DataFrame",
    knocked_out: list[str],
    w_bwm: np.ndarray,
    w_cm: np.ndarray,
    weights: np.ndarray,
    xi: float,
    criteria: list[str],
    closeness: "pd.Series",
    rai: "pd.DataFrame",
    cwv: dict,
    mc_results: "pd.DataFrame",
    allocation: dict,
    results: list,
) -> None:
    """
    Write pipeline intermediates to numbered CSV/JSON files in dump_dir.
    Each file is independently loadable — no Python needed to read them.
    """
    os.makedirs(dump_dir, exist_ok=True)

    # 00 — raw facts (the audit trail starts here)
    with open(os.path.join(dump_dir, "00_raw_facts.json"), "w") as f:
        json.dump(
            [{
                "jurisdiction": r.jurisdiction,
                "criterion_code": r.criterion_code,
                "raw_value": r.raw_value,
                "evidence_tag": r.evidence_tag.value,
                "source_citation": r.source_citation,
                "as_of": r.as_of.isoformat() if isinstance(r.as_of, date) else str(r.as_of),
                "alt_raw_value": r.alt_raw_value,
            } for r in facts],
            f, indent=2,
        )

    # 01 — decision matrix before knockout
    pre_knockout_matrix.to_csv(os.path.join(dump_dir, "01_decision_matrix.csv"), float_format="%.4f")

    # 02 — post-knockout matrix + who was dropped
    post_knockout_matrix.to_csv(os.path.join(dump_dir, "02_post_knockout_matrix.csv"), float_format="%.4f")
    with open(os.path.join(dump_dir, "02_knocked_out.json"), "w") as f:
        json.dump({"knocked_out": knocked_out}, f, indent=2)

    # 03 — weight vectors + consistency ratio
    with open(os.path.join(dump_dir, "03_weights.json"), "w") as f:
        json.dump({
            "w_bwm":      dict(zip(criteria, w_bwm.tolist())),
            "w_critic_m": dict(zip(criteria, w_cm.tolist())),
            "w_fused":    dict(zip(criteria, weights.tolist())),
            "bwm_consistency_xi": xi,
        }, f, indent=2)

    # 04 — TOPSIS closeness + rank
    cc_df = pd.DataFrame({
        "closeness": closeness,
        "rank": closeness.rank(ascending=False).astype(int),
    })
    cc_df.to_csv(os.path.join(dump_dir, "04_topsis_closeness.csv"), float_format="%.6f")

    # 05 — SMAA rank acceptability index + central weight vectors
    rai.to_csv(os.path.join(dump_dir, "05_smaa_rai.csv"), float_format="%.4f")
    with open(os.path.join(dump_dir, "05_smaa_central_weight_vectors.json"), "w") as f:
        json.dump(
            {jur: (v.tolist() if v is not None else None) for jur, v in cwv.items()},
            f, indent=2,
        )

    # 06 — Monte Carlo intervals
    mc_results.to_csv(os.path.join(dump_dir, "06_mc_intervals.csv"), float_format="%.6f")

    # 07 — Knapsack allocation
    with open(os.path.join(dump_dir, "07_knapsack_allocation.json"), "w") as f:
        json.dump({f"wave_{k+1}": v for k, v in allocation.items()}, f, indent=2)

    # 08 — Final results (the full RankingResult list)
    with open(os.path.join(dump_dir, "08_final_results.json"), "w") as f:
        json.dump([
            dataclasses.asdict(r) for r in results
        ], f, indent=2, default=str)




class RankingPipeline:
    """End-to-end market ranking pipeline from raw facts to RankingResult list."""

    def __init__(self, config: PipelineConfig | None = None):
        self.cfg = config or PipelineConfig()

    def run(
        self,
        facts: list[RawFact],
        margin_12mo: dict[str, float] | None = None,
        verbose: bool = True,
        dump_dir: str | None = None,
    ) -> tuple[list[RankingResult], dict]:
        """
        Execute the full pipeline and return ranked results + intermediate artifacts.

        Parameters
        ----------
        facts        : list of RawFact from the extraction pipeline
        margin_12mo  : dict jurisdiction → expected 12-month contribution margin (USD)
                       Required for the knapsack value function; can be omitted to skip V5.
        verbose      : whether to print stage-by-stage progress
        dump_dir     : optional directory path.  When set, every pipeline stage is
                       serialized to numbered CSV/JSON files (00_raw_facts.json …
                       08_final_results.json).  Each file is independently loadable
                       and re-verifiable without re-running the pipeline.

        Returns
        -------
        results      : list[RankingResult] sorted by rank
        artifacts    : dict of intermediate outputs (matrix, weights, rai, mc, allocation)
                       for debugging, logging, and downstream reporting
        """
        cfg = self.cfg

        # ---- V0: Matrix assembly + hard knockout -----------------------------------------
        if verbose: print("=== V0: Building decision matrix + knockout screen ===")
        matrix = build_decision_matrix(facts, MAPPING_FUNCTIONS)
        capital_required = extract_capital_required(facts)
        matrix = knockout_screen(matrix, capital_required, cfg.liquid_runway_usd)

        if matrix.empty:
            raise ValueError("All jurisdictions were knocked out by the capital screen. "
                             "Increase liquid_runway_usd or review C6 raw values.")

        # ---- V2: Weight vector -----------------------------------------------------------
        if verbose: print("=== V2: BWM + CRITIC-M weight fusion ===")
        w_bwm, xi = bwm_weights(
            CRITERIA, cfg.bwm_best_idx, cfg.bwm_worst_idx, cfg.bwm_a_B, cfg.bwm_a_W
        )
        w_cm   = critic_m_weights(matrix, BENEFIT_MASK)
        weights = fuse_weights(w_bwm, w_cm, cfg.weight_lambda)
        if verbose:
            print(f"  BWM consistency ratio xi = {xi:.4f}  "
                  f"({'OK' if xi < 0.1 else 'HIGH — consider re-surveying'})")
            for c, w in zip(CRITERIA, weights):
                print(f"  {c}: {w:.4f}")

        # ---- V3: TOPSIS-RAD point ranking -----------------------------------------------
        if verbose: print("=== V3: TOPSIS-RAD ranking ===")
        closeness = topsis_rad(matrix, weights, BENEFIT_MASK, cfg.vpl, cfg.dpl)
        ranked    = closeness.sort_values(ascending=False)
        if verbose:
            for rank, (jur, cc) in enumerate(ranked.items(), start=1):
                print(f"  #{rank} {jur}: closeness={cc:.4f}")

        # ---- V4a: SMAA ------------------------------------------------------------------
        if verbose: print(f"=== V4a: SMAA ({cfg.smaa_n_trials:,} trials) ===")
        rai, cwv = smaa_topsis(
            matrix, BENEFIT_MASK, cfg.vpl, cfg.dpl,
            n_trials=cfg.smaa_n_trials, seed=cfg.smaa_seed
        )

        # ---- V4b: Evidence-calibrated Monte Carlo ----------------------------------------
        if verbose: print(f"=== V4b: Monte Carlo ({cfg.mc_n_trials:,} trials) ===")
        mc_results = monte_carlo_robustness(
            base_matrix=matrix,
            facts=facts,
            weights=weights,
            benefit_mask=BENEFIT_MASK,
            vpl=cfg.vpl,
            dpl=cfg.dpl,
            n_trials=cfg.mc_n_trials,
            seed=cfg.mc_seed,
        )

        # ---- V5: Multi-period knapsack --------------------------------------------------
        allocation: dict[int, list[str]] = {}
        if margin_12mo is not None and cfg.wave_budgets:
            if verbose: print(f"=== V5: Knapsack ({len(cfg.wave_budgets)} waves) ===")
            allocation = solve_multi_period(
                closeness=closeness,
                capital_burden=capital_required,
                margin_12mo={m: margin_12mo.get(m, 0.0) for m in matrix.index},
                wave_budgets=cfg.wave_budgets,
                mutually_exclusive_groups=cfg.mutually_exclusive_groups,
                alpha=cfg.knapsack_alpha,
            )

        # ---- Assemble RankingResult list ------------------------------------------------
        market_to_wave: dict[str, int | None] = {}
        for wave_idx, chosen in allocation.items():
            for m in chosen:
                market_to_wave[m] = wave_idx + 1  # 1-indexed waves

        results: list[RankingResult] = []
        for rank, (jur, cc) in enumerate(ranked.items(), start=1):
            mc_row = mc_results.loc[jur] if jur in mc_results.index else None
            results.append(RankingResult(
                jurisdiction=jur,
                closeness=float(cc),
                rank=rank,
                rank_acceptability={int(col): float(rai.loc[jur, col]) for col in rai.columns},
                mc_90pct_interval=(
                    float(mc_row["p5"]) if mc_row is not None else 0.0,
                    float(mc_row["p95"]) if mc_row is not None else 0.0,
                ),
                expansion_wave=market_to_wave.get(jur, None),
            ))

        artifacts = {
            "decision_matrix": matrix,
            "weights": dict(zip(CRITERIA, weights)),
            "bwm_consistency_xi": xi,
            "closeness": closeness,
            "rai": rai,
            "central_weight_vectors": cwv,
            "mc_intervals": mc_results,
            "expansion_allocation": allocation,
        }

        # ---- Fix D: optional stage dump for independent verification --------------------
        if dump_dir is not None:
            pre_knockout = build_decision_matrix(facts, MAPPING_FUNCTIONS)
            knocked_out_list = [j for j in pre_knockout.index if j not in matrix.index]
            _dump_stage_artifacts(
                dump_dir=dump_dir,
                facts=facts,
                pre_knockout_matrix=pre_knockout,
                post_knockout_matrix=matrix,
                knocked_out=knocked_out_list,
                w_bwm=w_bwm,
                w_cm=w_cm,
                weights=weights,
                xi=xi,
                criteria=CRITERIA,
                closeness=closeness,
                rai=rai,
                cwv=cwv,
                mc_results=mc_results,
                allocation=allocation,
                results=results,
            )
            if verbose:
                print(f"=== Stage artifacts written to: {dump_dir} ===")

        return results, artifacts
